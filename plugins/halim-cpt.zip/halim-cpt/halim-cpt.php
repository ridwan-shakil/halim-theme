<?php

/**
 * Plugin Name: Halim Custom Post Type
 * Plugin URI: https://wpwebtool.com
 * Description: Handles the custom posts of halim theme with this plugin.
 * Version: 1.0.0
 * Requires at least: 5.2
 * Requires PHP: 7.2
 * Author: MD.Ridwan
 * Author URI: https://wpwebtool.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI: https://example.com/my-plugin/
 * Text Domain: halim-cpt
 * Domain Path: /languages
 **/

/**
 * Register a custom post type called "slider".
 *
 * @see get_post_type_labels() for label keys.
 */
function rs_custom_post_type()
{
    $labels = array(
        'name'                  => __('Slider',  'halim'),
        'singular_name'         => __('Slide',  'halim'),
        'menu_name'             => __('Slides',  'halim'),
        'name_admin_bar'        => __('Slider',  'halim'),
        'add_new'               => __('Add New Slide', 'halim'),
        'add_new_item'          => __('Add New Slide', 'halim'),
        'new_item'              => __('New Slide', 'halim'),
        'edit_item'             => __('Edit Slider', 'halim'),
        'view_item'             => __('View Slider', 'halim'),
        'all_items'             => __('All Slides', 'halim'),

    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'Slider'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('Slider', $args);
}

add_action('init', 'rs_custom_post_type');

/**
 * Register a custom post type called "Service".
 *
 * @see get_post_type_labels() for label keys.
 */
function rs_custom_post_type_services()
{
    $labels = array(
        'name'                  => __('Service',  'halim'),
        'singular_name'         => __('Service',  'halim'),
        'menu_name'             => __('Services',  'halim'),
        'name_admin_bar'        => __('Services',  'halim'),
        'add_new'               => __('Add New Service', 'halim'),
        'add_new_item'          => __('Add New Service', 'halim'),
        'new_item'              => __('New Service', 'halim'),
        'edit_item'             => __('Edit Service', 'halim'),
        'view_item'             => __('View Service', 'halim'),
        'all_items'             => __('All Services', 'halim'),

    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'Service'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor'),
    );

    register_post_type('Service', $args);
}

add_action('init', 'rs_custom_post_type_services');
/**
 * Register a custom post type called "Counter".
 *
 * @see get_post_type_labels() for label keys.
 */
function rs_custom_post_type_Counters()
{
    $labels = array(
        'name'                  => __('Counter',  'halim'),
        'singular_name'         => __('Counter',  'halim'),
        'menu_name'             => __('Counters',  'halim'),
        'name_admin_bar'        => __('Counters',  'halim'),
        'add_new'               => __('Add New Counter', 'halim'),
        'add_new_item'          => __('Add New Counter', 'halim'),
        'new_item'              => __('New Counter', 'halim'),
        'edit_item'             => __('Edit Counter', 'halim'),
        'view_item'             => __('View Counter', 'halim'),
        'all_items'             => __('All Counters', 'halim'),

    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'Counter'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title'),
    );

    register_post_type('Counter', $args);
}

add_action('init', 'rs_custom_post_type_Counters');
/**
 * Register a custom post type called "Counter".
 *
 * @see get_post_type_labels() for label keys.
 */
function rs_custom_post_type_Team_members()
{
    $labels = array(
        'name'                  => __('Team_member',  'halim'),
        'singular_name'         => __('Team member',  'halim'),
        'menu_name'             => __('Team members',  'halim'),
        'name_admin_bar'        => __('Team members',  'halim'),
        'add_new'               => __('Add New Team member', 'halim'),
        'add_new_item'          => __('Add New Team member', 'halim'),
        'new_item'              => __('New Team member', 'halim'),
        'edit_item'             => __('Edit Team member', 'halim'),
        'view_item'             => __('View Team member', 'halim'),
        'all_items'             => __('All Team members', 'halim'),

    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'Team_member'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'thumbnail'),
    );

    register_post_type('Team_member', $args);
}
add_action('init', 'rs_custom_post_type_Team_members');

// cnange placeholder text in team member post type 
function change_default_title_member($title)
{
    $screen = get_current_screen();

    if ('team_member' == $screen->post_type) {
        $title = 'Team member name';
    }

    return $title;
}
add_filter('enter_title_here', 'change_default_title_member');

/**
 * Register a custom post type called "Client Reviews".
 *
 * @see get_post_type_labels() for label keys.
 */
function rs_custom_post_type_client_review()
{
    $labels = array(
        'name'                  => __('client_reviews',  'halim'),
        'singular_name'         => __('Client review',  'halim'),
        'menu_name'             => __('Client reviews',  'halim'),
        'name_admin_bar'        => __('Client reviews',  'halim'),
        'add_new'               => __('Add New Client review', 'halim'),
        'add_new_item'          => __('Add New Client review', 'halim'),
        'new_item'              => __('New Client review', 'halim'),
        'edit_item'             => __('Edit Client review', 'halim'),
        'view_item'             => __('View Client review', 'halim'),
        'all_items'             => __('All Client reviews', 'halim'),

    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'client_review'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('client_review', $args);
}
add_action('init', 'rs_custom_post_type_client_review');

// cnange placeholder text in Client review post type 
function change_default_title_client_review($title)
{
    $screen = get_current_screen();

    if ('client_review' == $screen->post_type) {
        $title = 'Client name';
    }

    return $title;
}

add_filter('enter_title_here', 'change_default_title_client_review');

/**
 * Register a custom post type called "Portfolios".
 */
function rs_custom_post_type_portfolio()
{
    $labels = array(
        'name'                  => __('portfolios',  'halim'),
        'singular_name'         => __('Portfolio',  'halim'),
        'add_new'               => __('Add New Portfolio', 'halim'),
        'add_new_item'          => __('Add New Portfolio', 'halim'),
        'all_items'             => __('All Portfolios', 'halim'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'show_ui'            => true,
        // 'rewrite'            => array('slug' => 'portfolio'),
        'supports'           => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('portfolio', $args);
}
add_action('init', 'rs_custom_post_type_portfolio');

// cnange placeholder text in Portfolio post type 
function change_default_title_portfolio($title)
{
    $screen = get_current_screen();
    if ('portfolio' == $screen->post_type) {
        $title = 'Project Name';
    }
    return $title;
}
add_filter('enter_title_here', 'change_default_title_portfolio');

// Register texonomy for portfolio post type 
function wpdocs_create_book_taxonomies()
{
    $labels = array(
        'name'              => __('Categories', 'halim'),
        'singular_name'     => __('Category', 'halim'),
        'search_items'      => __('Search Categorys', 'halim'),
        'all_items'         => __('All Categorys', 'halim'),
        'parent_item'       => __('Parent Category', 'halim'),
        'parent_item_colon' => __('Parent Category:', 'halim'),
        'edit_item'         => __('Edit Category', 'halim'),
        'update_item'       => __('Update Category', 'halim'),
        'add_new_item'      => __('Add New Category', 'halim'),
        'new_item_name'     => __('New Category Name', 'halim'),
        'menu_name'         => __('Category', 'halim'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'portfolio-cat'),
        //added
        "public" => true,
        "publicly_queryable" => true,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "show_in_rest" => true,
        "show_tagcloud" => false,

    );

    register_taxonomy('portfolio-cat', 'portfolio', $args);
}
add_action('init', 'wpdocs_create_book_taxonomies');
